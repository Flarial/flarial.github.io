Any changes on the website can be done through /js/info.js
Please dont change anything other than the code in /js/info.js
